package controle;

/**
 *
 * @author Guilherme
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import conexao.Conexao;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.io.File;
import java.io.IOException;

public class FrmTelaCad extends JFrame {

    Conexao con_cliente;

    JMenuItem Sobre2, Cliente, Categoria, Sessao, Livro, sair_M;
    JMenu opcoes, Sobre, Sair;
    JMenuBar barra;

    JLabel rCodigo, rNome, rEmail, rTel, rData;
    JButton JCliente, JLivro, JCategoria, JSessao;
    ImageIcon imagens[];

    //Início do arredondamento do botão.
    class RoundButton extends JButton {

        private final Color backgroundColor = new Color(199, 208, 215); // Cor de fundo padrão

        public RoundButton(String label) {
            super(label);
            setContentAreaFilled(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            if (getModel().isArmed()) {
                g.setColor(backgroundColor);
            } else {
                g.setColor(getBackground());
            }
            g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 35, 35);
            super.paintComponent(g);
        }

        @Override
        protected void paintBorder(Graphics g) {
            g.setColor(getForeground());
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 35, 35);
        }

        Shape shape;

        @Override
        public boolean contains(int x, int y) {
            if (shape == null || !shape.getBounds().equals(getBounds())) {
                shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
            }
            return shape.contains(x, y);
        }
    }

    class ImagePanel extends JPanel {

        private Image backgroundImage;

        public ImagePanel(String imagePath) {
            try {
                backgroundImage = javax.imageio.ImageIO.read(new File(imagePath));
            } catch (IOException e) {
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this);
        }
    }

    public FrmTelaCad() {

        con_cliente = new Conexao(); // inicialização do objeto
        con_cliente.conecta(); // chama o método que conecta

        setTitle("Menu de Opções");
        ImagePanel backgroundPanel = new ImagePanel("imagem/Fundo_Menu.png");
        ImageIcon icone = new ImageIcon("Imagem/Logo3.png");
        setIconImage(icone.getImage());

        setResizable(false);
        Container tela = getContentPane();
        backgroundPanel.setLayout(null);

        JCliente = new RoundButton("Cliente");
        JLivro = new RoundButton("Livro");
        JCategoria = new RoundButton("Categoria");
        JSessao = new RoundButton("Sessão");

        JCliente.setBounds(155, 146, 250, 50);
        JLivro.setBounds(155, 218, 250, 50);
        JCategoria.setBounds(155, 290, 250, 50);
        JSessao.setBounds(155, 361, 250, 50);

        JCliente.setBackground(new Color(118, 127, 167)); // Cor do botão (azul)
        JLivro.setBackground(new Color(218, 169, 114)); // Cor do botão (Amarelo)
        JCategoria.setBackground(new Color(118, 127, 167)); // Cor do botão (azul)
        JSessao.setBackground(new Color(218, 169, 114)); // Cor do botão (Amarelo)

        barra = new JMenuBar();
        setJMenuBar(barra);
        opcoes = new JMenu("Opções");
        Sobre = new JMenu("Sobre");
        Sair = new JMenu("Sair");

        barra.setBackground(new Color(255, 255, 255));

        // Criar o JMenuItem "Cliente"
        Cliente = new JMenuItem("Cliente");
        opcoes.add(Cliente);

        Categoria = new JMenuItem("Categoria");
        opcoes.add(Categoria);

        Livro = new JMenuItem("Livro");
        opcoes.add(Livro);

        Sessao = new JMenuItem("Sessão");
        opcoes.add(Sessao);

        sair_M = new JMenuItem("Sair");
        Sair.add(sair_M);

        //Criar o JMenuItem "Sobre".
        Sobre2 = new JMenuItem("Sobre");
        Sobre.add(Sobre2);

        sair_M.addActionListener((ActionEvent e) -> {
            int opcao;
            Object[] botoes = {"Sim", "Não"};
            opcao = JOptionPane.showInternalOptionDialog(null, "Deseja mesmo sair?", "Sair", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, botoes, botoes[0]);
            if (opcao == JOptionPane.YES_OPTION) {
                System.exit(0);
            }
        });

        tela.add(JCliente);
        tela.add(JLivro);
        tela.add(JCategoria);
        tela.add(JSessao);

        barra.add(opcoes);
        barra.add(Sobre);
        barra.add(Sair);

        tela.add(backgroundPanel);
        setSize(1000, 550);
        setVisible(true);
        setLocationRelativeTo(null);

        // Configurar ação para o botão "Cliente"
        JCliente.addActionListener((ActionEvent e) -> {
            abrirTelaCliente();
        });

        //Configurar ação para a barra de menu "Cliente".
        Cliente.addActionListener((ActionEvent e) -> {
            abrirTelaCliente();
        });
        
         // Configurar ação para o botão "Livro"
        JLivro.addActionListener((ActionEvent e) -> {
            abrirTelaLivro();
        });
        
         //Configurar ação para a barra de menu "Livro".
        Livro.addActionListener((ActionEvent e) -> {
            abrirTelaLivro();
        });
        
         // Configurar ação para o botão "Categoria"
        JCategoria.addActionListener((ActionEvent e) -> {
            abrirTelaCategoria();
        });
        
         //Configurar ação para a barra de menu "Categoria".
        Categoria.addActionListener((ActionEvent e) -> {
            abrirTelaCategoria();
        });
        
         // Configurar ação para o botão "Sessão"
        JSessao.addActionListener((ActionEvent e) -> {
            abrirTelaSessao();
        });
        
         //Configurar ação para a barra de menu "Sessão".
        Sessao.addActionListener((ActionEvent e) -> {
            abrirTelaSessao();
        });
       
        // Configurar ação para o item "Sobre".
        Sobre2.addActionListener((ActionEvent e) -> {
            abrirTelaSobre();
        });

    }

    private void abrirTelaSobre() {
        // Fecha a tela atual
        dispose();

        // Abre a tela "TelaSobre"
        TelaSobre telaSobre = new TelaSobre();
        telaSobre.setVisible(true);
    }

    private void abrirTelaCliente() {
        // Fecha a tela atual
        dispose();

        // Abre a tela "TelaCliente"
        TelaCliente telaCliente = new TelaCliente();
        telaCliente.setVisible(true);
    }
    
    private void abrirTelaLivro() {
        // Fecha a tela atual
        dispose();

        // Abre a tela "TelaLivro"
        TelaLivro telaLivro = new TelaLivro();
        telaLivro.setVisible(true);
    }
    
     private void abrirTelaCategoria() {
        // Fecha a tela atual
        dispose();

        // Abre a tela "TelaCategoria"
        TelaCategoria telaCategoria = new TelaCategoria();
        telaCategoria.setVisible(true);
    }
     
     private void abrirTelaSessao() {
        // Fecha a tela atual
        dispose();

        // Abre a tela "TelaCategoria"
        TelaSessao telaSessao = new TelaSessao();
        telaSessao.setVisible(true);
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> {
            FrmTelaCad app = new FrmTelaCad();
            app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        });
    }
}
