/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.awt.*;
import java.text.*;
import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import conexao.Conexao;
import java.io.File;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

/**
 *
 * @author Guilherme
 */
// Classe TelaLivro(exemplo de implementação)
public class TelaLivro extends JFrame {

    Conexao con_cliente;

    JLabel rCodigo, rTitulo, rISBN, rCategoria, rAutor, rSessaoID;
    JTextField tcodigo, tTitulo, tpesq, tCategoria, tAutor, tSessaoID;
    JFormattedTextField isbn;
    MaskFormatter mISBN;
    JButton retor, prim, ant, pro, ult, novor, grava, alte, exc, pesq, sair;
    JTable livro; //datagrid
    JScrollPane scp_tabela; // container para o datagrid
    ImageIcon imagens[];

    class ImagePanel extends JPanel {

        private Image backgroundImage;

        public ImagePanel(String imagePath) {
            try {
                backgroundImage = javax.imageio.ImageIO.read(new File(imagePath));
            } catch (IOException e) {
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this);
        }
    }

    // Construtor da tela Livro
    public TelaLivro() {
        // Configurar a interface gráfica da tela do cliente aquicon_cliente = new Conexao(); // inicialização do objeto
        con_cliente = new Conexao(); // inicialização do objeto
        con_cliente.conecta(); // chama o método que conecta

        setTitle("Banco de Dados");

        ImagePanel backgroundPanel = new ImagePanel("Imagem/Fundo_Tabela.png");

        ImageIcon icone = new ImageIcon("Imagem/Logo2.png");
        setIconImage(icone.getImage());
        setResizable(false);
        Container tela = getContentPane();
        backgroundPanel.setLayout(null);

        //configuração da tela
        rCodigo = new JLabel("Código: ");
        rTitulo = new JLabel("Titulo do Livro: ");
        rISBN = new JLabel("ISBN: ");
        rCategoria = new JLabel("Categoria: ");
        rAutor = new JLabel("Autor: ");
        rSessaoID = new JLabel("ID da Sessão: ");

        prim = new JButton("Primeiro");
        ant = new JButton("Anterior");
        pro = new JButton("Próximo");
        ult = new JButton("Último");

        novor = new JButton("Novo Registro");
        grava = new JButton("Gravar");
        alte = new JButton("Alterar");
        exc = new JButton("Excluir");
        pesq = new JButton("Pesquisar");
        retor = new JButton("Retornar");

        sair = new JButton("Sair");

        String icones[] = {"icones/primeiro.png", "icones/anterior.png",
            "icones/proximo.png", "icones/ultimo.png", "icones/criar.png", "icones/gravar.png",
            "icones/alterar.png", "icones/delete.png", "icones/pesquisar.png", "icones/sair.png", "icones/retornar.png"};
        imagens = new ImageIcon[11];
        for (int i = 0; i < 11; i++) {
            imagens[i] = new ImageIcon(icones[i]);
        }

        prim = new JButton(imagens[0]);
        ant = new JButton(imagens[1]);
        pro = new JButton(imagens[2]);
        ult = new JButton(imagens[3]);
        novor = new JButton(imagens[4]);
        grava = new JButton(imagens[5]);
        alte = new JButton(imagens[6]);
        exc = new JButton(imagens[7]);
        pesq = new JButton(imagens[8]);
        sair = new JButton(imagens[9]);
        retor = new JButton(imagens[10]);

        ant.setToolTipText("Retorna um Registro");
        pro.setToolTipText("Avança um registro");
        prim.setToolTipText("Retornar para o Primeiro registro");
        ult.setToolTipText("Avança para o Último registro");

        grava.setToolTipText("Insere um novo registro");
        exc.setToolTipText("Exclui um registro");
        alte.setToolTipText("Altera um registro");
        novor.setToolTipText("Cria um novo registro");
        pesq.setToolTipText("Área de pesquisa de registros");

        sair.setToolTipText("Encerra o Programa");
        retor.setToolTipText("Retorna para o menu");

        ant.setBackground(new Color(218, 169, 114));
        pro.setBackground(new Color(218, 169, 114));
        prim.setBackground(new Color(218, 169, 114));
        ult.setBackground(new Color(218, 169, 114));

        grava.setBackground(new Color(218, 169, 114));
        exc.setBackground(new Color(218, 169, 114));
        alte.setBackground(new Color(218, 169, 114));
        novor.setBackground(new Color(218, 169, 114));
        pesq.setBackground(new Color(218, 169, 114));

        sair.setBackground(new Color(218, 169, 114));
        retor.setBackground(new Color(218, 169, 114));

        try {
            mISBN = new MaskFormatter("###-#-###-#####-#");
        } catch (ParseException excp) {
        }
        isbn = new JFormattedTextField(mISBN);

        tcodigo = new JTextField(5);
        tTitulo = new JTextField(5);
        tCategoria = new JTextField(5);
        tpesq = new JTextField(5);
        tAutor = new JTextField(5);
        tSessaoID = new JTextField(5);

        //formatação na tela
        rCodigo.setBounds(115, 75, 50, 20);
        rTitulo.setBounds(310, 75, 120, 20);
        rISBN.setBounds(580, 75, 120, 20);
        rCategoria.setBounds(750, 75, 90, 20);
        rAutor.setBounds(940, 75, 120, 20);
        rSessaoID.setBounds(1110, 75, 150, 20);

        tcodigo.setBounds(50, 95, 183, 20);
        tTitulo.setBounds(235, 95, 265, 20);
        tCategoria.setBounds(692, 95, 180, 20);
        tpesq.setBounds(390, 330, 250, 20);
        tAutor.setBounds(875, 95, 180, 20);
        tSessaoID.setBounds(1057, 95, 182, 20);

        isbn.setBounds(504, 95, 185, 20);

        prim.setBounds(50, 330, 80, 20);
        ant.setBounds(1060, 330, 80, 20);
        pro.setBounds(150, 330, 80, 20);
        ult.setBounds(1160, 330, 80, 20);

        novor.setBounds(50, 390, 80, 20);
        grava.setBounds(150, 390, 80, 20);
        alte.setBounds(1060, 390, 80, 20);
        exc.setBounds(1160, 390, 80, 20);
        pesq.setBounds(650, 330, 250, 20);

        sair.setBounds(270, 390, 370, 20);
        retor.setBounds(650, 390, 370, 20); // Posição e tamanho do botão

        tpesq.setText("Titulo do Livro. (Apagar esse comentário)");

        retor.addActionListener((ActionEvent e) -> {
            dispose(); // Fecha a janela atual (TelaLivro)
            FrmTelaCad frmTelaCad = new FrmTelaCad();
            frmTelaCad.setVisible(true);
        });

        //funcão dos botões
        sair.addActionListener((ActionEvent e) -> {
            int opcaosair;
            Object[] botoessair = {"Sim", "Não"};
            opcaosair = JOptionPane.showOptionDialog(null, "Você deseja mesmo sair?", "Saindo...", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, botoessair, botoessair[0]);
            if (opcaosair == JOptionPane.YES_NO_OPTION) {
                System.exit(0);
            }
        });

        prim.addActionListener((ActionEvent e) -> {
            try {
                con_cliente.resultset.first();
                mostrar_Dados();
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro.");
            }
        });

        ant.addActionListener((ActionEvent e) -> {
            try {
                if (con_cliente.resultset.isFirst()) {
                    JOptionPane.showMessageDialog(null, "Você já está presente no primero registro.");
                } else {
                    con_cliente.resultset.previous();
                    mostrar_Dados();
                }
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro.");
            }
        });

        pro.addActionListener((ActionEvent e) -> {
            try {
                if (con_cliente.resultset.isLast()) {
                    JOptionPane.showMessageDialog(null, "Você já está presente no último registro.");
                } else {
                    con_cliente.resultset.next();
                    mostrar_Dados();
                }

            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro.");
            }
        });

        ult.addActionListener((ActionEvent e) -> {
            try {
                con_cliente.resultset.last();
                mostrar_Dados();
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro");
            }
        });

        novor.addActionListener((ActionEvent e) -> {
            tcodigo.setText("");
            tTitulo.setText("");
            isbn.setText("");
            tCategoria.setText("");
            tAutor.setText("");
            tSessaoID.setText("");
            tcodigo.requestFocus();
        });

        grava.addActionListener((ActionEvent e) -> {
            String titulo = tTitulo.getText();
            String Isbn = isbn.getText();
            String categoria = tCategoria.getText();
            String autor = tAutor.getText();
            String sessaoid = tSessaoID.getText();

            try {
                String insert_sql = "INSERT INTO livro (Titulo, ISBN, Categoria, Autor, SessaoID) VALUES ('" + titulo + "','" + Isbn + "','" + categoria + "','" + autor + "','" + sessaoid + "')";

                con_cliente.statement.executeUpdate(insert_sql);
                JOptionPane.showMessageDialog(null, "Gravação realizada com sucesso!!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);

                con_cliente.executaSQL("select * from livro order by Codigo_Livro");
                preencherTabela();
            } catch (SQLException errosql) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        alte.addActionListener((ActionEvent e) -> {
            String titulo = tTitulo.getText();
            String Isbn = isbn.getText();
            String categoria = tCategoria.getText();
            String autor = tAutor.getText();
            String sessaoid = tSessaoID.getText();
            String sql;
            String msg = "";

            try {
                if (tcodigo.getText().equals("")) {
                    sql = "insert into livro (Titulo, ISBN, Categoria, Autor, SessaoID) values ('" + titulo + "','" + Isbn + "','" + categoria + "','" + autor + "','" + sessaoid + "')";
                    msg = "Gravação de um novo registro";
                } else {
                    sql = "update livro set Titulo='" + titulo + "', ISBN='" + Isbn + "', Categoria='" + categoria + "', Autor='" + autor + "', SessaoID='" + sessaoid + "' where Codigo_Livro = " + tcodigo.getText();

                    msg = "Alteração de registro";
                }

                con_cliente.statement.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Gravação realizada com sucesso!!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);

                con_cliente.executaSQL("select * from livro order by Codigo_Livro");
                preencherTabela();

            } catch (SQLException errosql) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        exc.addActionListener((ActionEvent e) -> {
            String sql = "";
            try {
                int resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja excluir o registro: ", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION, 3);
                if (resposta == 0) {
                    sql = "delete from livro where Codigo_Livro = " + tcodigo.getText();
                    int excluir = con_cliente.statement.executeUpdate(sql);
                    if (excluir == 1) {
                        JOptionPane.showMessageDialog(null, "Exclusão realizada com sucesso!!", "Mensagem do programa", JOptionPane.INFORMATION_MESSAGE);
                        con_cliente.executaSQL("select * from livro order by Codigo_Livro");
                        con_cliente.resultset.first();
                        preencherTabela();
                        posicionarRegistro();
                    } else {
                        JOptionPane.showMessageDialog(null, "Operação cancelada pelo usuário!", "Menssagem do Programa", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            } catch (SQLException excecao) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + excecao, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        pesq.addActionListener((ActionEvent e) -> {
            try {
                String pesquisa = "select * from livro where Titulo like '" + tpesq.getText() + "%'";
                con_cliente.executaSQL(pesquisa);

                if (con_cliente.resultset.first()) {
                    preencherTabela();
                } else {
                    JOptionPane.showMessageDialog(null, "\n Não existe dados com este paramêtro!! \n ", "Mensagem do Programa,", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException errosql) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        //configuração da Jtable
        livro = new javax.swing.JTable();
        scp_tabela = new javax.swing.JScrollPane();
        livro.setBounds(50, 260, 550, 200);
        scp_tabela.setBounds(50, 120, 1190, 200);
        tela.add(livro);
        tela.add(scp_tabela);

        livro.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        livro.setFont(new java.awt.Font("Arial", 5, 13));

        livro.setBackground(new Color(255, 255, 255));

        livro.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{
                    {null, null, null, null, null},
                    {null, null, null, null, null},
                    {null, null, null, null, null},
                    {null, null, null, null, null},
                    {null, null, null, null, null}
                },
                new String[]{"Codigo do Livro", "Titulo do Livro", "ISBN", "Categoria", "Autor", "ID da Sessão"}) {
            boolean[] canEdit = new boolean[]{false, false, false, false, false, false};

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        scp_tabela.setViewportView(livro);
        livro.setAutoCreateRowSorter(true);

        tela.add(rCodigo);
        tela.add(rTitulo);
        tela.add(rISBN);
        tela.add(rCategoria);
        tela.add(rAutor);
        tela.add(rSessaoID);

        tela.add(tcodigo);
        tela.add(tTitulo);
        tela.add(tCategoria);
        tela.add(tpesq);
        tela.add(tAutor);
        tela.add(tSessaoID);
        tela.add(isbn);

        tela.add(prim);
        tela.add(ant);
        tela.add(pro);
        tela.add(ult);

        tela.add(novor);
        tela.add(grava);
        tela.add(alte);
        tela.add(exc);
        tela.add(pesq);

        tela.add(sair);
        tela.add(retor);
        tela.add(backgroundPanel);

        con_cliente.executaSQL("select * from livro order by Codigo_Livro");
        preencherTabela();
        posicionarRegistro();
    }

    TelaLivro(Object object, String adição, boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void preencherTabela() {
        livro.getColumnModel().getColumn(0).setPreferredWidth(3);
        livro.getColumnModel().getColumn(1).setPreferredWidth(100);
        livro.getColumnModel().getColumn(2).setPreferredWidth(20);
        livro.getColumnModel().getColumn(3).setPreferredWidth(14);
        livro.getColumnModel().getColumn(4).setPreferredWidth(14);
        livro.getColumnModel().getColumn(5).setPreferredWidth(3);

        DefaultTableModel modelo = (DefaultTableModel) livro.getModel();
        modelo.setNumRows(0);

        try {
            con_cliente.resultset.beforeFirst();
            while (con_cliente.resultset.next()) {
                modelo.addRow(new Object[]{
                    con_cliente.resultset.getString("Codigo_Livro"),
                    con_cliente.resultset.getString("Titulo"),
                    con_cliente.resultset.getString("ISBN"),
                    con_cliente.resultset.getString("Categoria"),
                    con_cliente.resultset.getString("Autor"),
                    con_cliente.resultset.getString("SessaoID")
                }
                );
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "\n Erro ao listar dados da tabela!! :\n " + erro, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }

//método posicionarRegistro
    public void posicionarRegistro() {
        try {
            con_cliente.resultset.first(); // posiciona no 1° registro da tabela
            mostrar_Dados(); // chama o método que irá buscar o dado da tabela
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Não foi possível posicionar no primeiro registro: " + erro, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void mostrar_Dados() {
        try {
            tcodigo.setText(con_cliente.resultset.getString("Codigo_Livro"));
            tTitulo.setText(con_cliente.resultset.getString("Titulo"));
            isbn.setText(con_cliente.resultset.getString("ISBN"));
            tCategoria.setText(con_cliente.resultset.getString("Categoria"));
            tAutor.setText(con_cliente.resultset.getString("Autor"));
            tSessaoID.setText(con_cliente.resultset.getString("SessaoID"));
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Não localizou dados: " + erro, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }

        setTitle("Livro");
        setSize(1300, 600);
        setLocationRelativeTo(null); // Centraliza a janela no meio
    }
}
