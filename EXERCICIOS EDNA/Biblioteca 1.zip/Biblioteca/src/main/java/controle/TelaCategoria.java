/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import conexao.Conexao;
import java.io.File;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

/**
 *
 * @author Guilherme
 */
// Classe TelaCategoria (exemplo de implementação)
public class TelaCategoria extends JFrame {

    Conexao con_cliente;

    JLabel rCategoria, rDescricao, rFaixaEtaria;
    JTextField tpesq, tCategoria, tDescricao, tFaixaEtaria;
    JButton retor, prim, ant, pro, ult, novor, grava, alte, exc, pesq, sair;
    JTable categoria; //datagrid
    JScrollPane scp_tabela; // container para o datagrid
    ImageIcon imagens[];

    class ImagePanel extends JPanel {

        private Image backgroundImage;

        public ImagePanel(String imagePath) {
            try {
                backgroundImage = javax.imageio.ImageIO.read(new File(imagePath));
            } catch (IOException e) {
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this);
        }
    }

    // Construtor da tela Categoria
    public TelaCategoria() {
        // Configurar a interface gráfica da tela do cliente aquicon_cliente = new Conexao(); // inicialização do objeto
        con_cliente = new Conexao(); // inicialização do objeto
        con_cliente.conecta(); // chama o método que conecta

        setTitle("Banco de Dados");

        ImagePanel backgroundPanel = new ImagePanel("Imagem/Fundo_Tabela.png");

        ImageIcon icone = new ImageIcon("Imagem/Logo2.png");
        setIconImage(icone.getImage());
        setResizable(false);
        Container tela = getContentPane();
        backgroundPanel.setLayout(null);

        rCategoria = new JLabel("Categoria: ");
        rDescricao = new JLabel("Descrição: ");
        rFaixaEtaria = new JLabel("Faixa Etária: ");

        prim = new JButton("Primeiro");
        ant = new JButton("Anterior");
        pro = new JButton("Próximo");
        ult = new JButton("Último");

        novor = new JButton("Novo Registro");
        grava = new JButton("Gravar");
        alte = new JButton("Alterar");
        exc = new JButton("Excluir");
        pesq = new JButton("Pesquisar");
        retor = new JButton("Retornar");

        sair = new JButton("Sair");

        String icones[] = {"icones/primeiro.png", "icones/anterior.png",
            "icones/proximo.png", "icones/ultimo.png", "icones/criar.png", "icones/gravar.png",
            "icones/alterar.png", "icones/delete.png", "icones/pesquisar.png", "icones/sair.png", "icones/retornar.png"};
        imagens = new ImageIcon[11];
        for (int i = 0; i < 11; i++) {
            imagens[i] = new ImageIcon(icones[i]);
        }

        prim = new JButton(imagens[0]);
        ant = new JButton(imagens[1]);
        pro = new JButton(imagens[2]);
        ult = new JButton(imagens[3]);
        novor = new JButton(imagens[4]);
        grava = new JButton(imagens[5]);
        alte = new JButton(imagens[6]);
        exc = new JButton(imagens[7]);
        pesq = new JButton(imagens[8]);
        sair = new JButton(imagens[9]);
        retor = new JButton(imagens[10]);

        ant.setToolTipText("Retorna um Registro");
        pro.setToolTipText("Avança um registro");
        prim.setToolTipText("Retornar para o Primeiro registro");
        ult.setToolTipText("Avança para o Último registro");

        grava.setToolTipText("Insere um novo registro");
        exc.setToolTipText("Exclui um registro");
        alte.setToolTipText("Altera um registro");
        novor.setToolTipText("Cria um novo registro");
        pesq.setToolTipText("Área de pesquisa de registros");

        sair.setToolTipText("Encerra o Programa");
        retor.setToolTipText("Retorna para o menu");

        ant.setBackground(new Color(218, 169, 114));
        pro.setBackground(new Color(218, 169, 114));
        prim.setBackground(new Color(218, 169, 114));
        ult.setBackground(new Color(218, 169, 114));

        grava.setBackground(new Color(218, 169, 114));
        exc.setBackground(new Color(218, 169, 114));
        alte.setBackground(new Color(218, 169, 114));
        novor.setBackground(new Color(218, 169, 114));
        pesq.setBackground(new Color(218, 169, 114));

        sair.setBackground(new Color(218, 169, 114));
        retor.setBackground(new Color(218, 169, 114));

        tCategoria = new JTextField(5);
        tpesq = new JTextField(5);
        tDescricao = new JTextField(5);
        tFaixaEtaria = new JTextField(5);

        //formatação na tela
        rCategoria.setBounds(200, 75, 80, 20);
        rDescricao.setBounds(610, 75, 120, 20);
        rFaixaEtaria.setBounds(1020, 75, 120, 20);

        tCategoria.setBounds(50, 95, 367, 20);
        tDescricao.setBounds(418, 95, 448, 20);
        tpesq.setBounds(390, 330, 250, 20);
        tFaixaEtaria.setBounds(868, 95, 372, 20);

        prim.setBounds(50, 330, 80, 20);
        ant.setBounds(1060, 330, 80, 20);
        pro.setBounds(150, 330, 80, 20);
        ult.setBounds(1160, 330, 80, 20);

        novor.setBounds(50, 390, 80, 20);
        grava.setBounds(150, 390, 80, 20);
        alte.setBounds(1060, 390, 80, 20);
        exc.setBounds(1160, 390, 80, 20);
        pesq.setBounds(650, 330, 250, 20);

        sair.setBounds(270, 390, 370, 20);
        retor.setBounds(650, 390, 370, 20); // Posição e tamanho do botão

        tpesq.setText("Descrição das Categorias. (Apagar esse comentário)");

        retor.addActionListener((ActionEvent e) -> {
            dispose(); // Fecha a janela atual (TelaCategoria)
            FrmTelaCad frmTelaCad = new FrmTelaCad();
            frmTelaCad.setVisible(true);
        });

        //funcão dos botões
        sair.addActionListener((ActionEvent e) -> {
            int opcaosair;
            Object[] botoessair = {"Sim", "Não"};
            opcaosair = JOptionPane.showOptionDialog(null, "Você deseja mesmo sair?", "Saindo...", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, botoessair, botoessair[0]);
            if (opcaosair == JOptionPane.YES_NO_OPTION) {
                System.exit(0);
            }
        });

        prim.addActionListener((ActionEvent e) -> {
            try {
                con_cliente.resultset.first();
                mostrar_Dados();
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro.");
            }
        });

        ant.addActionListener((ActionEvent e) -> {
            try {
                if (con_cliente.resultset.isFirst()) {
                    JOptionPane.showMessageDialog(null, "Você já está presente no primero registro.");
                } else {
                    con_cliente.resultset.previous();
                    mostrar_Dados();
                }
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro.");
            }
        });

        pro.addActionListener((ActionEvent e) -> {
            try {
                if (con_cliente.resultset.isLast()) {
                    JOptionPane.showMessageDialog(null, "Você já está presente no último registro.");
                } else {
                    con_cliente.resultset.next();
                    mostrar_Dados();
                }

            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro.");
            }
        });

        ult.addActionListener((ActionEvent e) -> {
            try {
                con_cliente.resultset.last();
                mostrar_Dados();
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro");
            }
        });

        novor.addActionListener((ActionEvent e) -> {
            tCategoria.setText("");
            tDescricao.setText("");
            tFaixaEtaria.setText("");
            tCategoria.requestFocus();
        });

        grava.addActionListener((ActionEvent e) -> {
            String categoriaa = tCategoria.getText();
            String descricao = tDescricao.getText();
            String faixaetaria = tFaixaEtaria.getText();

            try {
                String insert_sql = "INSERT INTO categoria (Categoria, Descricao, FaixaEtaria) VALUES ('" + categoriaa + "','" + descricao + "','" + faixaetaria + "')";

                con_cliente.statement.executeUpdate(insert_sql);
                JOptionPane.showMessageDialog(null, "Gravação realizada com sucesso!!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);

                con_cliente.executaSQL("select * from categoria order by Categoria");
                preencherTabela();
            } catch (SQLException errosql) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        alte.addActionListener((ActionEvent e) -> {
            String categoriaa = tCategoria.getText();
            String descricao = tDescricao.getText();
            String faixaetaria = tFaixaEtaria.getText();
            String sql;
            String msg = "";

            try {
                if (tCategoria.getText().equals("")) {
                    sql = "insert into categoria (Categoria, Descricao, FaixaEtaria) VALUES ('" + categoriaa + "','" + descricao + "','" + faixaetaria + "')";
                } else {
                    sql = "update categoria set Categoria='" + categoriaa + "', Descricao='" + descricao + "', FaixaEtaria='" + faixaetaria + "' where Categoria = " + tCategoria.getText();

                    msg = "Alteração de registro";
                }

                con_cliente.statement.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Gravação realizada com sucesso!!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);

                con_cliente.executaSQL("select * from categoria order by Categoria");
                preencherTabela();

            } catch (SQLException errosql) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        exc.addActionListener((ActionEvent e) -> {
            String sql = "";
            try {
                int resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja excluir o registro: ", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION, 3);
                if (resposta == 0) {
                    sql = "delete from categoria where Categoria = " + tCategoria.getText();
                    int excluir = con_cliente.statement.executeUpdate(sql);
                    if (excluir == 1) {
                        JOptionPane.showMessageDialog(null, "Exclusão realizada com sucesso!!", "Mensagem do programa", JOptionPane.INFORMATION_MESSAGE);
                        con_cliente.executaSQL("select * from categoria order by Categoria");
                        con_cliente.resultset.first();
                        preencherTabela();
                        posicionarRegistro();
                    } else {
                        JOptionPane.showMessageDialog(null, "Operação cancelada pelo usuário!", "Menssagem do Programa", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            } catch (SQLException excecao) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + excecao, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        pesq.addActionListener((ActionEvent e) -> {
            try {
                String pesquisa = "select * from categoria where Descricao like '" + tpesq.getText() + "%'";
                con_cliente.executaSQL(pesquisa);

                if (con_cliente.resultset.first()) {
                    preencherTabela();
                } else {
                    JOptionPane.showMessageDialog(null, "\n Não existe dados com este paramêtro!! \n ", "Mensagem do Programa,", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException errosql) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        //configuração da Jtable
        categoria = new javax.swing.JTable();
        scp_tabela = new javax.swing.JScrollPane();
        categoria.setBounds(50, 260, 550, 200);
        scp_tabela.setBounds(50, 120, 1190, 200);
        tela.add(categoria);
        tela.add(scp_tabela);

        categoria.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        categoria.setFont(new java.awt.Font("Arial", 5, 13));

        categoria.setBackground(new Color(255, 255, 255));

        categoria.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{
                    {null, null, null, null, null},
                    {null, null, null, null, null},
                    {null, null, null, null, null}
                },
                new String[]{"Categoria do Livro", "Descrição do Livro", "Faixa Etária"}) {
            boolean[] canEdit = new boolean[]{false, false, false};

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        scp_tabela.setViewportView(categoria);
        categoria.setAutoCreateRowSorter(true);

        tela.add(rCategoria);
        tela.add(rDescricao);
        tela.add(rFaixaEtaria);

        tela.add(tCategoria);
        tela.add(tpesq);
        tela.add(tDescricao);
        tela.add(tFaixaEtaria);

        tela.add(prim);
        tela.add(ant);
        tela.add(pro);
        tela.add(ult);

        tela.add(novor);
        tela.add(grava);
        tela.add(alte);
        tela.add(exc);
        tela.add(pesq);

        tela.add(sair);
        tela.add(retor);
        tela.add(backgroundPanel);

        con_cliente.executaSQL("select * from categoria order by Categoria");
        preencherTabela();
        posicionarRegistro();
    }

    TelaCategoria(Object object, String adição, boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void preencherTabela() {
        categoria.getColumnModel().getColumn(0).setPreferredWidth(3);
        categoria.getColumnModel().getColumn(1).setPreferredWidth(100);
        categoria.getColumnModel().getColumn(2).setPreferredWidth(20);

        DefaultTableModel modelo = (DefaultTableModel) categoria.getModel();
        modelo.setNumRows(0);

        try {
            con_cliente.resultset.beforeFirst();
            while (con_cliente.resultset.next()) {
                modelo.addRow(new Object[]{
                    con_cliente.resultset.getString("Categoria"),
                    con_cliente.resultset.getString("Descricao"),
                    con_cliente.resultset.getString("FaixaEtaria")
                }
                );
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "\n Erro ao listar dados da tabela!! :\n " + erro, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }

//método posicionarRegistro
    public void posicionarRegistro() {
        try {
            con_cliente.resultset.first(); // posiciona no 1° registro da tabela
            mostrar_Dados(); // chama o método que irá buscar o dado da tabela
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Não foi possível posicionar no primeiro registro: " + erro, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void mostrar_Dados() {
        try {
            tCategoria.setText(con_cliente.resultset.getString("Categoria"));
            tDescricao.setText(con_cliente.resultset.getString("Descricao"));
            tFaixaEtaria.setText(con_cliente.resultset.getString("FaixaEtaria"));
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Não localizou dados: " + erro, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }

        setTitle("Categoria");
        setSize(1300, 600);
        setLocationRelativeTo(null); // Centraliza a janela no meio
    }
}
