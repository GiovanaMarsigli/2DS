-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 30-Out-2023 às 17:49
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `clientes`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria`
--

CREATE TABLE `categoria` (
  `Descricao` varchar(50) NOT NULL,
  `Categoria` int(11) NOT NULL,
  `FaixaEtaria` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `categoria`
--

INSERT INTO `categoria` (`Descricao`, `Categoria`, `FaixaEtaria`) VALUES
('Livros infantis: Emocionantes e inspiradores.', 1, 'De 4 a 12'),
('Suspense: Enigmas e tensão envolventes.', 2, 'De 15 a 50'),
('Ficção científica: Futuro, tecnologia.', 9, 'de 16 a 50');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `ClienteID` int(11) NOT NULL,
  `Nome` varchar(50) NOT NULL,
  `Email` varchar(80) NOT NULL,
  `Telefone` varchar(15) NOT NULL,
  `Endereco` varchar(70) NOT NULL,
  `Nascimento` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`ClienteID`, `Nome`, `Email`, `Telefone`, `Endereco`, `Nascimento`) VALUES
(1, 'Audilene', 'Audilene@gmail.com', '(11) 90394-3423', 'Rua Constela Ovenaria', '08/09/1978'),
(2, 'Keli', 'Keli@outlook.com', '(11) 94530-4365', 'Avenida Pereira da Silva', '21/09/1987'),
(3, 'Diana ', 'Diana@gmail.com', '(11) 97234-2146', 'Rua Manuela Queiroz', '05/04/1993');

-- --------------------------------------------------------

--
-- Estrutura da tabela `emprestimo`
--

CREATE TABLE `emprestimo` (
  `EmprestimoID` int(11) NOT NULL,
  `Data` date NOT NULL,
  `ClienteID` int(11) NOT NULL,
  `DataDevolucao` date NOT NULL,
  `CodigoLivro` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `livro`
--

CREATE TABLE `livro` (
  `Codigo_Livro` int(11) NOT NULL,
  `Titulo` varchar(50) NOT NULL,
  `ISBN` varchar(60) NOT NULL,
  `Categoria` int(11) NOT NULL,
  `Autor` varchar(50) NOT NULL,
  `SessaoID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `livro`
--

INSERT INTO `livro` (`Codigo_Livro`, `Titulo`, `ISBN`, `Categoria`, `Autor`, `SessaoID`) VALUES
(1, 'Sombras do Passado', '978-9-876-54321-0', 2, 'Isabella France', 3),
(2, 'Caminho para o Desconhecido ', '978-1-234-56788-0', 9, 'Gabriel Martins', 9),
(3, 'As Aventuras de Luna e Reino dos Sonhos', '978-5-555-55555-5', 1, 'Sofia Pereira', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sessao`
--

CREATE TABLE `sessao` (
  `Descricao` varchar(50) NOT NULL,
  `SessaoID` int(11) NOT NULL,
  `Localizacao` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `sessao`
--

INSERT INTO `sessao` (`Descricao`, `SessaoID`, `Localizacao`) VALUES
('Sessão com livros de suspense', 3, 'Sessão letra C'),
('Sessão com livros infantis', 2, 'Sessão letra B'),
('Sessão com livros de ficção cientifica', 9, 'Sessão letra I');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `Usuario` varchar(60) NOT NULL,
  `Senha` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`Usuario`, `Senha`) VALUES
('Gibs', 'gibspink123'),
('Gihyaa', 'gigiheart15'),
('Gui', 'hotdogdofelix');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`Categoria`);

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`ClienteID`);

--
-- Índices para tabela `emprestimo`
--
ALTER TABLE `emprestimo`
  ADD PRIMARY KEY (`EmprestimoID`);

--
-- Índices para tabela `livro`
--
ALTER TABLE `livro`
  ADD PRIMARY KEY (`Codigo_Livro`);

--
-- Índices para tabela `sessao`
--
ALTER TABLE `sessao`
  ADD PRIMARY KEY (`SessaoID`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `ClienteID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `livro`
--
ALTER TABLE `livro`
  MODIFY `Codigo_Livro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
