/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.geom.RoundRectangle2D;

public class TelaSobre extends JFrame {

    RoundButton Voltar;

    class ImagePanel extends JPanel {
        private Image backgroundImage;

        public ImagePanel(String imagePath) {
            try {
                backgroundImage = javax.imageio.ImageIO.read(new File(imagePath));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this);
        }
    }

    public TelaSobre() {
        setTitle("Sobre");
        ImagePanel backgroundPanel = new ImagePanel("imagem/Fundo_Sobre.png");
        ImageIcon icone = new ImageIcon("Imagem/Logo3.png");
        setIconImage(icone.getImage());
        
        Container tela = getContentPane();
        backgroundPanel.setLayout(null);
        setResizable(false);

        Voltar = new RoundButton("Voltar");
        Voltar.setBounds(590, 518, 100, 40); // Centraliza o botão na tela
        
        Voltar.setBackground(new Color (218, 169, 114));

        Voltar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                retornarParaFrmTelaCad();
            }
        });

        tela.add(Voltar);

        tela.add(backgroundPanel);
        setSize(1300, 600); // Aumento do tamanho da janela
        setLocationRelativeTo(null); // Centraliza a janela no meio
        setVisible(true);
    }

    private void retornarParaFrmTelaCad() {
        dispose(); // Fecha a tela atual (TelaSobre)

        // Abre a tela FrmTelaCad
        SwingUtilities.invokeLater(() -> {
            FrmTelaCad telaPrincipal = new FrmTelaCad();
            telaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        });
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> {
            TelaSobre app = new TelaSobre();
            app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        });
    }
}