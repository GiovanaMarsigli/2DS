package controle;

import conexao.Conexao;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import java.awt.geom.RoundRectangle2D;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

//Início do arredondamento do botão.
class RoundButton extends JButton {

    private final Color backgroundColor = new Color(199, 208, 215); // Cor de fundo padrão

    public RoundButton(String label) {
        super(label);
        setContentAreaFilled(false);
    }

    protected void paintComponent(Graphics g) {
        if (getModel().isArmed()) {
            g.setColor(backgroundColor);
        } else {
            g.setColor(getBackground());
        }
        g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 35, 35);
        super.paintComponent(g);
    }

    protected void paintBorder(Graphics g) {
        g.setColor(getForeground());
        g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 35, 35);
    }

    Shape shape;

    public boolean contains(int x, int y) {
        if (shape == null || !shape.getBounds().equals(getBounds())) {
            shape = new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 15, 15);
        }
        return shape.contains(x, y);
    }
}

// Fim do arredondamento.
public class FrmLogin extends JFrame {

    Conexao con_cliente;
    JPasswordField tsen;
    JLabel usuario, senha, mensagemErro;
    JTextField tusu;
    RoundButton blogar; // Usando o RoundButton personalizado

    int tentativas = 3;

    class ImagePanel extends JPanel {

        private Image backgroundImage;

        public ImagePanel(String imagePath) {
            try {
                backgroundImage = javax.imageio.ImageIO.read(new File(imagePath));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this);
        }
    }

    public FrmLogin() {

        con_cliente = new Conexao();
        con_cliente.conecta();

        setTitle("Login");
        ImagePanel backgroundPanel = new ImagePanel("imagem/Fundo.png");
        ImageIcon icone = new ImageIcon("imagem/Logo.png");

        setIconImage(icone.getImage());
        Container tela = getContentPane();
        backgroundPanel.setLayout(null);
        setResizable(false);

        ImageIcon usua = new ImageIcon("icones/pessoa.png");
        ImageIcon se = new ImageIcon("icones/cadeado.png");

        blogar = new RoundButton("Entrar"); // Usando o botão arredondado
        tsen = new JPasswordField(10);
        tusu = new JTextField(10);
        usuario = new JLabel(usua);
        senha = new JLabel(se);

        mensagemErro = new JLabel();
        mensagemErro.setForeground(Color.RED); // Cor do texto de erro

        blogar.setBackground(new Color(228, 141, 122)); // Cor do botão (azul)
        blogar.setForeground(Color.WHITE); // Cor do texto do botão

        tusu.setBounds(140, 80, 150, 30);
        tsen.setBounds(140, 120, 150, 30);

        senha.setBounds(95, 115, 50, 40);
        usuario.setBounds(95, 75, 50, 40);

        blogar.setBounds(165, 170, 100, 40);
        mensagemErro.setBounds(100, 237, 300, 20); // Posição da mensagem de erro

        // Alinhar o texto dentro do botão
        blogar.setHorizontalTextPosition(JButton.CENTER);
        blogar.setVerticalTextPosition(JButton.CENTER);

        tela.add(tsen);
        tela.add(senha);
        tela.add(usuario);

        tela.add(tusu);
        tela.add(blogar);
        tela.add(mensagemErro);

        blogar.addActionListener((ActionEvent e) -> {
            try {

                String pesquisa = "select * from usuario where Usuario like '" + tusu.getText() + "' && Senha = '" + tsen.getText() + "'";
                con_cliente.executaSQL(pesquisa);

                if (con_cliente.resultset.first()) {
                    // Acessa o form do cadastro
                    JOptionPane.showMessageDialog(null, "Login Efetuado com sucesso \n Seja Bem Vindo: " + tusu.getText());
                    FrmTelaCad mostra = new FrmTelaCad();
                    mostra.setVisible(true);
                    dispose();

                } else {
                    tentativas--;
                    if (tentativas > 0) {
                        mensagemErro.setText("Senha incorreta. Tentativas restantes: " + tentativas);
                    } else {
                        mensagemErro.setText("Você excedeu o limite de tentativas.");

                        // Exibe uma mensagem antes de fechar o formulário
                        JOptionPane.showMessageDialog(null, "Você excedeu o limite de tentativas. O formulário será fechado.");

                        // Fecha o formulário
                        dispose();
                    }
                }

            } catch (SQLException errosql) {
                // Trate exceções aqui
            }
        });
        tela.add(backgroundPanel);
        setSize(450, 300); // Aumento do tamanho da janela
        setLocationRelativeTo(null); // Centraliza a janela no meio
        setVisible(true);
    }

    public static void main(String args[]) {
        SwingUtilities.invokeLater(() -> {
            FrmLogin app = new FrmLogin();
            app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        });
    }
}
