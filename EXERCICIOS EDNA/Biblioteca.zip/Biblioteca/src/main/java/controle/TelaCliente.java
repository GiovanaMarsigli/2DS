/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import java.awt.*;
import java.text.*;
import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import conexao.Conexao;
import java.io.File;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

/**
 *
 * @author Guilherme
 */
// Classe TelaCliente (exemplo de implementação)
public class TelaCliente extends JFrame {

    Conexao con_cliente;

    JLabel rCodigo, rNome, rEmail, rTel, rData, rEndereco;
    JTextField tcodigo, tnome, temail, tpesq, tendereco;
    JFormattedTextField tel, data;
    MaskFormatter mTel, mData;
    JButton retor, prim, ant, pro, ult, novor, grava, alte, exc, pesq, sair;
    JTable clientes; //datagrid
    JScrollPane scp_tabela; // container para o datagrid
    ImageIcon imagens[];

    class ImagePanel extends JPanel {

        private Image backgroundImage;

        public ImagePanel(String imagePath) {
            try {
                backgroundImage = javax.imageio.ImageIO.read(new File(imagePath));
            } catch (IOException e) {
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, this.getWidth(), this.getHeight(), this);
        }
    }

    // Construtor da tela do cliente
    public TelaCliente() {
        // Configurar a interface gráfica da tela do cliente aquicon_cliente = new Conexao(); // inicialização do objeto
        con_cliente = new Conexao(); // inicialização do objeto
        con_cliente.conecta(); // chama o método que conecta

        setTitle("Banco de Dados");

        ImagePanel backgroundPanel = new ImagePanel("Imagem/Fundo_Tabela.png");

        ImageIcon icone = new ImageIcon("Imagem/Logo2.png");
        setIconImage(icone.getImage());
        setResizable(false);
        Container tela = getContentPane();
        backgroundPanel.setLayout(null); // Você já definiu um layout nulo no ImagePanel

        //configuração da tela
        rCodigo = new JLabel("Código: ");
        rNome = new JLabel("Nome do Cliente: ");
        rData = new JLabel("Data de Nascimento: ");
        rTel = new JLabel("Telefone: ");
        rEmail = new JLabel("Email do Cliente: ");
        rEndereco = new JLabel("Endereco do Cliente: ");

        prim = new JButton("Primeiro");
        ant = new JButton("Anterior");
        pro = new JButton("Próximo");
        ult = new JButton("Último");

        novor = new JButton("Novo Registro");
        grava = new JButton("Gravar");
        alte = new JButton("Alterar");
        exc = new JButton("Excluir");
        pesq = new JButton("Pesquisar");
        retor = new JButton("Retornar");

        sair = new JButton("Sair");

        String icones[] = {"icones/primeiro.png", "icones/anterior.png",
            "icones/proximo.png", "icones/ultimo.png", "icones/criar.png", "icones/gravar.png",
            "icones/alterar.png", "icones/delete.png", "icones/pesquisar.png", "icones/sair.png", "icones/retornar.png"};
        imagens = new ImageIcon[11];
        for (int i = 0; i < 11; i++) {
            imagens[i] = new ImageIcon(icones[i]);
        }

        prim = new JButton(imagens[0]);
        ant = new JButton(imagens[1]);
        pro = new JButton(imagens[2]);
        ult = new JButton(imagens[3]);
        novor = new JButton(imagens[4]);
        grava = new JButton(imagens[5]);
        alte = new JButton(imagens[6]);
        exc = new JButton(imagens[7]);
        pesq = new JButton(imagens[8]);
        sair = new JButton(imagens[9]);
        retor = new JButton(imagens[10]);

        ant.setToolTipText("Retorna um Registro");
        pro.setToolTipText("Avança um registro");
        prim.setToolTipText("Retornar para o Primeiro registro");
        ult.setToolTipText("Avança para o Último registro");

        grava.setToolTipText("Insere um novo registro");
        exc.setToolTipText("Exclui um registro");
        alte.setToolTipText("Altera um registro");
        novor.setToolTipText("Cria um novo registro");
        pesq.setToolTipText("Área de pesquisa de registros");

        sair.setToolTipText("Encerra o Programa");
        retor.setToolTipText("Retorna para o menu");

        ant.setBackground(new Color(218, 169, 114));
        pro.setBackground(new Color(218, 169, 114));
        prim.setBackground(new Color(218, 169, 114));
        ult.setBackground(new Color(218, 169, 114));

        grava.setBackground(new Color(218, 169, 114));
        exc.setBackground(new Color(218, 169, 114));
        alte.setBackground(new Color(218, 169, 114));
        novor.setBackground(new Color(218, 169, 114));
        pesq.setBackground(new Color(218, 169, 114));

        sair.setBackground(new Color(218, 169, 114));
        retor.setBackground(new Color(218, 169, 114));

        try {
            mData = new MaskFormatter("##/##/####");
            mTel = new MaskFormatter("(##)#####-####");
        } catch (ParseException excp) {
        }
        tel = new JFormattedTextField(mTel);
        data = new JFormattedTextField(mData);

        tcodigo = new JTextField(5);
        tnome = new JTextField(5);
        temail = new JTextField(5);
        tpesq = new JTextField(5);
        tendereco = new JTextField(5);

        //formatação na tela
        rCodigo.setBounds(115, 75, 50, 20);
        rNome.setBounds(310, 75, 120, 20);
        rData.setBounds(1070, 75, 120, 20);
        rTel.setBounds(740, 75, 60, 20);
        rEmail.setBounds(525, 75, 120, 20);
        rEndereco.setBounds(890, 75, 150, 20);

        tcodigo.setBounds(50, 95, 183, 20);
        tnome.setBounds(235, 95, 265, 20);
        temail.setBounds(502, 95, 185, 20);
        tpesq.setBounds(390, 330, 250, 20);
        tendereco.setBounds(875, 95, 178, 20);

        data.setBounds(1055, 95, 185, 20);
        tel.setBounds(690, 95, 183, 20);

        prim.setBounds(50, 330, 80, 20);
        ant.setBounds(1060, 330, 80, 20);
        pro.setBounds(150, 330, 80, 20);
        ult.setBounds(1160, 330, 80, 20);

        novor.setBounds(50, 390, 80, 20);
        grava.setBounds(150, 390, 80, 20);
        alte.setBounds(1060, 390, 80, 20);
        exc.setBounds(1160, 390, 80, 20);
        pesq.setBounds(650, 330, 250, 20);

        sair.setBounds(270, 390, 370, 20);
        retor.setBounds(650, 390, 370, 20); // Posição e tamanho do botão

        tpesq.setText("Nome do cliente. (Apagar esse comentário)");

        retor.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Aqui você pode adicionar o código para retornar ao "FrmTelaCad"
                dispose(); // Fecha a janela atual (TelaCliente)
                // Crie e exiba a janela "FrmTelaCad" aqui
                FrmTelaCad frmTelaCad = new FrmTelaCad();
                frmTelaCad.setVisible(true);
            }
        });

        //funcão dos botões
        sair.addActionListener((ActionEvent e) -> {
            int opcaosair;
            Object[] botoessair = {"Sim", "Não"};
            opcaosair = JOptionPane.showOptionDialog(null, "Você deseja mesmo sair?", "Saindo...", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, botoessair, botoessair[0]);
            if (opcaosair == JOptionPane.YES_NO_OPTION) {
                System.exit(0);
            }
        });

        prim.addActionListener((ActionEvent e) -> {
            try {
                con_cliente.resultset.first();
                mostrar_Dados();
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro.");
            }
        });

        ant.addActionListener((ActionEvent e) -> {
            try {
                if (con_cliente.resultset.isFirst()) {
                    JOptionPane.showMessageDialog(null, "Você já está presente no primero registro.");
                } else {
                    con_cliente.resultset.previous();
                    mostrar_Dados();
                }
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro.");
            }
        });

        pro.addActionListener((ActionEvent e) -> {
            try {
                if (con_cliente.resultset.isLast()) {
                    JOptionPane.showMessageDialog(null, "Você já está presente no último registro.");
                } else {
                    con_cliente.resultset.next();
                    mostrar_Dados();
                }

            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro.");
            }
        });

        ult.addActionListener((ActionEvent e) -> {
            try {
                con_cliente.resultset.last();
                mostrar_Dados();
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(null, "Não foi possível acessar o primeiro registro");
            }
        });

        novor.addActionListener((ActionEvent e) -> {
            tcodigo.setText("");
            tnome.setText("");
            temail.setText("");
            tel.setText("");
            tendereco.setText("");
            data.setText("");
            tcodigo.requestFocus();
        });

        grava.addActionListener((ActionEvent e) -> {
            String nome = tnome.getText();
            String email = temail.getText();
            String telefone = tel.getText();
            String endereco = tendereco.getText();
            String data_nasc = data.getText();

            try {
                String insert_sql = "INSERT INTO cliente (Nome, Email, Telefone, Endereco, Nascimento) VALUES ('" + nome + "','" + email + "','" + telefone + "','" + endereco + "','" + data_nasc + "')";

                con_cliente.statement.executeUpdate(insert_sql);
                JOptionPane.showMessageDialog(null, "Gravação realizada com sucesso!!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);

                con_cliente.executaSQL("select * from cliente order by ClienteID");
                preencherTabela();
            } catch (SQLException errosql) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        alte.addActionListener((ActionEvent e) -> {
            String nome = tnome.getText();
            String email = temail.getText();
            String telefone = tel.getText();
            String endereco = tendereco.getText();
            String data_nasc = data.getText();
            String sql;
            String msg = "";

            try {
                if (tcodigo.getText().equals("")) {
                    sql = "insert into cliente (Nome, Email, Telefone, Endereco, Nascimento) values ('" + nome + "','" + email + "','" + telefone + "','" + endereco + "','" + data_nasc + "')";
                    msg = "Gravação de um novo registro";
                } else {
                    sql = "update cliente set Nome='" + nome + "', Email='" + email + "', Telefone='" + telefone + "', Endereco='" + endereco + "', Nascimento='" + data_nasc + "' where ClienteID = " + tcodigo.getText();

                    msg = "Alteração de registro";
                }

                con_cliente.statement.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Gravação realizada com sucesso!!", "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);

                con_cliente.executaSQL("select * from cliente order by ClienteID");
                preencherTabela();

            } catch (SQLException errosql) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        exc.addActionListener((ActionEvent e) -> {
            String sql = "";
            try {
                int resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja excluir o registro: ", "Confirmar Exclusão", JOptionPane.YES_NO_OPTION, 3);
                if (resposta == 0) {
                    sql = "delete from cliente where ClienteID = " + tcodigo.getText();
                    int excluir = con_cliente.statement.executeUpdate(sql);
                    if (excluir == 1) {
                        JOptionPane.showMessageDialog(null, "Exclusão realizada com sucesso!!", "Mensagem do programa", JOptionPane.INFORMATION_MESSAGE);
                        con_cliente.executaSQL("select * from cliente order by ClienteID");
                        con_cliente.resultset.first();
                        preencherTabela();
                        posicionarRegistro();
                    } else {
                        JOptionPane.showMessageDialog(null, "Operação cancelada pelo usuário!", "Menssagem do Programa", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            } catch (SQLException excecao) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + excecao, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        pesq.addActionListener((ActionEvent e) -> {
            try {
                String pesquisa = "select * from cliente where Nome like '" + tpesq.getText() + "%'";
                con_cliente.executaSQL(pesquisa);

                if (con_cliente.resultset.first()) {
                    preencherTabela();
                } else {
                    JOptionPane.showMessageDialog(null, "\n Não existe dados com este paramêtro!! \n ", "Mensagem do Programa,", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException errosql) {
                JOptionPane.showMessageDialog(null, "\n Erro na gravação :\n " + errosql, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        //configuração da Jtable
        clientes = new javax.swing.JTable();
        scp_tabela = new javax.swing.JScrollPane();
        clientes.setBounds(50, 260, 550, 200);
        scp_tabela.setBounds(50, 120, 1190, 200);
        tela.add(clientes);
        tela.add(scp_tabela);

        clientes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        clientes.setFont(new java.awt.Font("Arial", 5, 13));

        clientes.setBackground(new Color(255, 255, 255));

        clientes.setModel(new javax.swing.table.DefaultTableModel(
                new Object[][]{
                    {null, null, null, null, null},
                    {null, null, null, null, null},
                    {null, null, null, null, null},
                    {null, null, null, null, null},
                    {null, null, null, null, null}
                },
                new String[]{"Código", "Nome", "Email", "Telefone", "Endereço", "Data de Nascimento"}) {
            boolean[] canEdit = new boolean[]{false, false, false, false, false, false};

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        scp_tabela.setViewportView(clientes);
        clientes.setAutoCreateRowSorter(true);

        tela.add(rCodigo);
        tela.add(rNome);
        tela.add(rEmail);
        tela.add(rTel);
        tela.add(rData);
        tela.add(rEndereco);

        tela.add(tcodigo);
        tela.add(tnome);
        tela.add(temail);
        tela.add(tpesq);
        tela.add(tendereco);
        tela.add(data);
        tela.add(tel);

        tela.add(prim);
        tela.add(ant);
        tela.add(pro);
        tela.add(ult);

        tela.add(novor);
        tela.add(grava);
        tela.add(alte);
        tela.add(exc);
        tela.add(pesq);

        tela.add(sair);
        tela.add(retor);
        tela.add(backgroundPanel);

        con_cliente.executaSQL("select * from cliente order by ClienteID");
        preencherTabela();
        posicionarRegistro();
    }

    TelaCliente(Object object, String adição, boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void preencherTabela() {
        clientes.getColumnModel().getColumn(0).setPreferredWidth(3);
        clientes.getColumnModel().getColumn(1).setPreferredWidth(100);
        clientes.getColumnModel().getColumn(2).setPreferredWidth(20);
        clientes.getColumnModel().getColumn(3).setPreferredWidth(14);
        clientes.getColumnModel().getColumn(4).setPreferredWidth(14);
        clientes.getColumnModel().getColumn(5).setPreferredWidth(6);

        DefaultTableModel modelo = (DefaultTableModel) clientes.getModel();
        modelo.setNumRows(0);

        try {
            con_cliente.resultset.beforeFirst();
            while (con_cliente.resultset.next()) {
                modelo.addRow(new Object[]{
                    con_cliente.resultset.getString("ClienteID"),
                    con_cliente.resultset.getString("Nome"),
                    con_cliente.resultset.getString("Email"),
                    con_cliente.resultset.getString("Telefone"),
                    con_cliente.resultset.getString("Endereco"),
                    con_cliente.resultset.getString("Nascimento")
                }
                );
            }
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "\n Erro ao listar dados da tabela!! :\n " + erro, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }

//método posicionarRegistro
    public void posicionarRegistro() {
        try {
            con_cliente.resultset.first(); // posiciona no 1° registro da tabela
            mostrar_Dados(); // chama o método que irá buscar o dado da tabela
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Não foi possível posicionar no primeiro registro: " + erro, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public void mostrar_Dados() {
        try {
            tcodigo.setText(con_cliente.resultset.getString("ClienteID"));
            tnome.setText(con_cliente.resultset.getString("Nome"));
            temail.setText(con_cliente.resultset.getString("Email"));
            tel.setText(con_cliente.resultset.getString("Telefone"));
            tendereco.setText(con_cliente.resultset.getString("Endereco"));
            data.setText(con_cliente.resultset.getString("Nascimento"));
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(null, "Não localizou dados: " + erro, "Mensagem do Programa", JOptionPane.INFORMATION_MESSAGE);
        }

        setTitle("Tela do Cliente");
        setSize(1300, 600);
        setLocationRelativeTo(null); // Centraliza a janela no meio
    }
}
