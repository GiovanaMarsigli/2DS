<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    
    <title>Giovana's Version</title>
    <link rel="icon" href="img/logo.png" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="860x860" href="img/logo.png">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #875F76;
            color: white;
            font-size: 18px;
        }
        .navbar {
            font-size: 20px;
            color: #875F76;
        }
        input[type="text"] {
            border-radius: 10px;
            padding: 10px;
            border: 1px solid #ccc;
        }
        .center-form {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; 
        }
    </style>
</head>
<body class="p-3 m-0 border-0 bd-example">
    <nav class="navbar navbar-expand-lg" style="background-color: #875F76;">
        <div class="container-fluid">
            <a class="navbar-brand" href="menu.html">
                <img src="img/logomids.png" alt="LOGO" width="" height="100">
            </a>       
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            LIVROS
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="listarlivro.php">LISTAR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="cadastrarlivro.php">INCLUIR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="alterarlivro.php">ALTERAR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="excluirlivro.php">EXCLUIR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="pesquisarlivro.php">PESQUISAR</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            AUTORES
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="listarautor.php">LISTAR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="cadastrarautor.php">INCLUIR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="alterarautor.php">ALTERAR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="excluirautor.php">EXCLUIR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="pesquisarautor.php">PESQUISAR</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            AUTORIAS
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="listarautoria.php">LISTAR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="cadastrarautoria.php">INCLUIR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="alterarautoria.php">ALTERAR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="excluirautoria.php">EXCLUIR</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="pesquisarautoria.php">PESQUISAR</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Outros
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="sb.php">Sobre</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="fc.php">Fale conosco</a></li>
              </ul>
            </li>   </ul>
            </div>
        </div>
    </nav>
    <div class="center-form">
    <img class="srounded float-end img-fluid rounded d-none d-lg-block d-none d-lg-block" src="img/pesquisar.png" alt="Imagem de exemplo" style="width: 700px;"> 

        <form name="cliente" method="POST" action="" class="form-container">
            <fieldset id="a">
                <legend><b>Pesquisar:</b></legend>
                <p>Informe o nome do autor: <br><input name="getNomeAutor" type="text" size="60" maxlength="40"></p> 
            </fieldset>
            <br>
            <fieldset id="b">
                <legend><b>Opções:</b></legend>
                <br>
                <button class="btn btn-outline-light" type="submit" name="btnenviar">Pesquisar</button>
                <button class="btn btn-outline-light" type="reset" name="limpar">Limpar</button>
                <a class="btn btn-outline-light" href="menu.html">Voltar</a>
            </fieldset>
            <fieldset id="c">
          <?php
            extract($_POST, EXTR_OVERWRITE);
            if (isset($btnenviar))
            {
                include_once 'Autor.php';
                $p = new Autor();
                $p->setNomeAutor($getNomeAutor . "%");
                $pro_bd = $p->consultar();
                foreach ($pro_bd as $pro_mostrar) {
                    ?>
                    <br>
                    <b> <?php echo $pro_mostrar[0]; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <b> <?php echo $pro_mostrar[1]; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <b> <?php echo $pro_mostrar[2]; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <b> <?php echo $pro_mostrar[3]; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <b> <?php echo $pro_mostrar[4]; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <?php
                }
            }
            ?>
          
        </fieldset>
</body>
</html>