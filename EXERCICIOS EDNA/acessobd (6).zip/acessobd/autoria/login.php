<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
   

    <title>Giovana's Version</title>
    <link rel="icon" href="img/logo.png" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="860x860" href="img/logo.png">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

   
   <style>
        body {
            background-image: url('img/tsaut.jpg');
            background-size: cover; /* Isso garante que a imagem de fundo cubra toda a tela */
            background-position: center; /* Centraliza a imagem de fundo */
            background-repeat: no-repeat;
            color: #fff;
            font-family: 'Helvetica', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-container {
            background-color:  #875F76;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
            width: 300px;
            text-align: center;
        }

        h1 {
            color: #fff;
            font-size: 36px;
            margin-bottom: 30px;
            font-family: 'Noto Serif', sans-serif;
        }

        input[type="text"], input[type="password"] {
            border: none;
            border-bottom: 2px solid #fff;
            background: transparent;
            outline: none;
            color: #fff;
            margin-bottom: 20px;
            padding: 10px;
            width: 100%;
        }

        input[type="submit"] {
            background-color: #fff;
            color: #000;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #fff;
        }

     
    </style>


<script language="javascript">
        function bloquearLetras(event) {
            var charCode = event.which || event.keyCode;
            if (charCode < 48 || charCode > 57) {
                event.preventDefault();
                return false;
            }
            return true;
        }
    </script>
</head>
<body>

<div class="login-container">
    <h1>Midnights Login</h1>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
        <input type="text" placeholder="Login" name="txtlogin" required>
        <input type="password" placeholder="Senha" name="txtsenha" onkeypress="return bloquearLetras(event)" required>
        <input type="submit" value="Login" name="btnconsultar">
    </form>
</div>

<?php
if (isset($_POST['btnconsultar'])) {
    extract($_POST, EXTR_OVERWRITE);
    include_once 'usuario.php';
    $u = new Usuario();
    $u->setUsu($txtlogin);
    $u->setSenha($txtsenha);
    $pro_bd = $u->logar();

    $existe = false;
    foreach ($pro_bd as $pro_mostrar) {
        $existe = true;
        ?>
        <br><b><?php echo "Seja muito bem-vindo(a) Usuario: " .$pro_mostrar[0]; ?></b><br><br>
        <input type="button"  name="btnentrar" class="btn-entrar"> <a href="menu.html"> Entrar </a>
        <?php
    }
    if (!$existe) {
        header("location:loginInvalido.html");
    }
}
?>

</body>
</html>