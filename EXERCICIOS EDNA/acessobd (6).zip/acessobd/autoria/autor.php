<?php
include_once 'conectar.php';

class Autor
{
    private $Cod_autor;
    private $NomeAutor;
    private $Sobrenome;
    private $Email;
    private $Nasc;
    private $conn;

    public function getCod_autor()
    {
        return $this->Cod_autor;
    }
    public function setCod_autor($codautor)
    {
        $this->Cod_autor = $codautor;
    }
    public function getNomeAutor()
    {
        return $this->NomeAutor;
    }
    public function setNomeAutor($Nomeautor)
    {
        $this->NomeAutor = $Nomeautor;
    }
    public function getSobrenome()
    {
        return $this->Sobrenome;
    }
    public function setSobrenome($sobrenome)
    {
        $this->Sobrenome = $sobrenome;
    }
    public function getEmail()
    {
        return $this->Email;
    }
    public function setEmail($email)
    {
        $this->Email = $email;
    }
    public function getNasc()
    {
        return $this->Nasc;
    }
    public function setNasc($nasc)
    {
        $this->Nasc = $nasc;
    }

  function salvar()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("INSERT INTO autor VALUES (null, ?, ?, ?, ?)");
            @$sql->bindParam(1, $this->getNomeautor(), PDO::PARAM_STR);
            @$sql->bindParam(2, $this->getSobrenome(), PDO::PARAM_STR);
            @$sql->bindParam(3, $this->getEmail(), PDO::PARAM_STR);
            @$sql->bindParam(4, $this->getNasc(), PDO::PARAM_STR);
            if ($sql->execute() == 1) {
                return "Registro salvo com sucesso!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao salvar o registro. " . $exc->getMessage();
        }
    }

    function alterar(){
        try {
           $this->conn = new Conectar();
           $sql = $this->conn->prepare("SELECT * FROM autor WHERE Cod_autor = ?"); 
           @$sql-> bindParam(1, $this->getCod_autor(), PDO::PARAM_STR); 
           $sql->execute();
           return $sql->fetchAll();
           $this->conn = null;
}
      catch(PDOException $exc) {
      echo "Erro ao alterar. " . $exc->getMessage();

       }

   }

    function alterar2()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("UPDATE autor SET NomeAutor = ?, Sobrenome = ?, Email = ?, Nasc = ? WHERE Cod_autor = ?");
            @$sql->bindParam(1, $this->getNomeautor(), PDO::PARAM_STR);
            @$sql->bindParam(2, $this->getSobrenome(), PDO::PARAM_STR);
            @$sql->bindParam(3, $this->getEmail(), PDO::PARAM_STR);
            @$sql->bindParam(4, $this->getNasc(), PDO::PARAM_STR);
            @$sql->bindParam(5, $this->getCod_autor(), PDO::PARAM_STR);
            if ($sql->execute() == 1) {
                return "Registro alterado com sucesso!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao salvar o registro. " . $exc->getMessage();
        }
    }

    function consultar()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("SELECT * FROM autor WHERE Nomeautor LIKE ?");
            @$sql->bindParam(1, $this->getNomeAutor(), PDO::PARAM_STR);
            $sql->execute();
            return $sql->fetchAll();
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao executar consulta. " . $exc->getMessage();
        }
    }
    function exclusao()
    {
        try {
            $this->conn = new Conectar();
            $cod_autor = $this->getCod_autor(); // Atribuir o valor a uma variável
            $sql = $this->conn->prepare("DELETE FROM autor WHERE Cod_autor = ?");
            $sql->bindParam(1, $cod_autor, PDO::PARAM_STR); // Usar a variável aqui
            if ($sql->execute() == 1) {
                return "Excluído com sucesso!";
            } else {
                return "Erro na exclusão!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao excluir. " . $exc->getMessage();
        }
    }
    

    
    function listar()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("SELECT * FROM autor ORDER BY Cod_autor");
            $sql->execute();
            return $sql->fetchAll();
            $this->conn = null;
        } catch (PDOException $e) {
            echo "Erro ao executar consulta. " . $e->getMessage();
        }
    }
}    
?>
