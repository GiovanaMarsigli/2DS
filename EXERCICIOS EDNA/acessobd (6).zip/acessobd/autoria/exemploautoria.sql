-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 13-Nov-2023 às 19:24
-- Versão do servidor: 10.4.22-MariaDB
-- versão do PHP: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `exemploautoria`
--
CREATE DATABASE `exemploautoria`;
USE `exemploautoria`;
-- --------------------------------------------------------

--
-- Estrutura da tabela `autor`
--

CREATE TABLE `autor` (
  `Cod_autor` int(11) NOT NULL,
  `NomeAutor` varchar(50) NOT NULL,
  `Sobrenome` varchar(30) NOT NULL,
  `Email` varchar(25) NOT NULL,
  `Nasc` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `autor`
--

INSERT INTO `autor` (`Cod_autor`, `NomeAutor`, `Sobrenome`, `Email`, `Nasc`) VALUES
(1, 'Collen Hoover', 'Hoover', 'collenhoover@gmail.com', '11/12/1979'),
(2, 'Clarice Lispector', 'Lispector', 'claricelspector@gmail.com', '10/12/1920'),
(3, 'Taylor Jenkins Reid', 'Jenkins Reid', 'taylorjenkinsreid@gmail.c', '20/12/1983'),
(4, 'Casey McQuiston', 'McQuiston', 'caseymcquiston@gmail.com', '21/01/1991'),
(5, 'E. Lockhart', 'Lockhart', 'lockhart@gmail.com', '13/09/1967'),
(6, ' Holly Black', 'Black', 'holly@gmail.com', '10/11/1971'),
(7, 'Jenna Evans Welch', 'Evans Welch', 'jennaevans@gmail.com', '14/12/1971'),
(8, 'aa', 'aa', 'aa', 'aa');

-- --------------------------------------------------------

--
-- Estrutura da tabela `autoria1`
--

CREATE TABLE `autoria1` (
  `Cod_autor` int(11) NOT NULL,
  `Cod_livro` int(11) NOT NULL,
  `DataLancamento` varchar(15) NOT NULL,
  `Editoria` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `autoria1`
--

INSERT INTO `autoria1` (`Cod_autor`, `Cod_livro`, `DataLancamento`, `Editoria`) VALUES
(1, 1, '29/02/2016', 'Galera'),
(2, 2, '18/10/2022', 'Galera'),
(3, 3, '05/10/2022', 'Galera'),
(4, 4, '18/10/2012', 'Galera'),
(5, 5, '05/12/2015', 'Galera'),
(6, 6, '05/02/2021', 'Galera'),
(7, 7, '30/02/2015', 'Galera'),
(8, 8, '05/05/2015', 'Galera'),
(0, 0, 'aa', 'aa');

-- --------------------------------------------------------

--
-- Estrutura da tabela `livro`
--

CREATE TABLE `livro` (
  `Cod_livro` int(11) NOT NULL,
  `Titulo` varchar(50) NOT NULL,
  `Categoria` varchar(30) NOT NULL,
  `ISBN` varchar(13) NOT NULL,
  `Idioma` varchar(25) NOT NULL,
  `QtdePag` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `livro`
--

INSERT INTO `livro` (`Cod_livro`, `Titulo`, `Categoria`, `ISBN`, `Idioma`, `QtdePag`) VALUES
(1, 'É Assim que Acaba', 'Romance', '9781501110668', 'Português - Brasil', 368),
(2, 'O lado feio do amor', 'Romance', '9788501106254', 'Português - Brasil', 336),
(3, 'Até o verão terminar', 'Romance', '9786559810376', 'Português - Brasil', 336),
(4, 'É Assim que Começa', 'Romance', '9786559812219', 'Português - Brasil', 336),
(5, 'Verity', 'Mistério, Thriller e Suspense', '9783423437288', 'Português - Brasil', 320),
(6, 'ggy', 'aa', 'aaa', 'aa', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `Login` varchar(5) NOT NULL,
  `Senha` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`Login`, `Senha`) VALUES
('a', 123),
('b', 456);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `autor`
--
ALTER TABLE `autor`
  ADD PRIMARY KEY (`Cod_autor`);

--
-- Índices para tabela `livro`
--
ALTER TABLE `livro`
  ADD PRIMARY KEY (`Cod_livro`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `autor`
--
ALTER TABLE `autor`
  MODIFY `Cod_autor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `livro`
--
ALTER TABLE `livro`
  MODIFY `Cod_livro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
