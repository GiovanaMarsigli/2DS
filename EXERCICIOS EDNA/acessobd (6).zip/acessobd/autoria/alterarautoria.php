<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    
  <title>Giovana's Version</title>
  <link rel="icon" href="img/logo.png" type="image/x-icon">
  <link rel="apple-touch-icon" sizes="860x860" href="img/logo.png">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    function blokletras(event) {
      var key = event.key;
      if (!isNaN(key) || key === 'Backspace') {
        return true;
      } else {
        return false;
      }
    }
  </script> <style>
body {
      background-color: #875F76;
      color: white;
      font-size: 18px;
    }

    .navbar {
      font-size: 20px;
      color: #875F76;
    }

    input[type="text"] {
      border-radius: 10px;
      padding: 10px;
      border: 1px solid #ccc;
    }

    .center-form {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 10vh;
    }
    </style>
  </head>
  <body class="p-3 m-0 border-0 bd-example">
    <nav class="navbar navbar-expand-lg" style="background-color: #875F76;">
      <div class="container-fluid">
        <a class="navbar-brand" href="menu.html">
          <img src="img/logomids.png" alt="LOGO" width="" height="100">
        </a>       
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                LIVROS
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="listarlivro.php">LISTAR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="cadastrarlivro.php">INCLUIR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="alterarlivro.php">ALTERAR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="excluirlivro.php">EXCLUIR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="pesquisarlivro.php">PESQUISAR</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                AUTORES
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="listarautor.php">LISTAR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="cadastrarautor.php">INCLUIR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="alterarautor.php">ALTERAR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="excluirautor.php">EXCLUIR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="pesquisarautor.php">PESQUISAR</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                AUTORIAS
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="listarautoria.php">LISTAR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="cadastrarautoria.php">INCLUIR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="alterarautoria.php">ALTERAR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="excluirautoria.php">EXCLUIR</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="pesquisarautoria.php">PESQUISAR</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Outros
              </a>
              <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="sb.php">Sobre</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="fc.php">Fale conosco</a></li>
              </ul>
            </li></ul>
        </div>
      </div>
    </nav>
    <form name="cliente" method="POST" action="alterarautoria2.php">
          <fieldset class="form-container">
          <div class="container text-center">
            <legend><b> Informe o código do autor desejado: </b></legend>
            <p>Código do autor: <input name="codautor" type="text" size="20" maxlength="5" placeholder="Código do autor" onkeypress="return blokletras(event)"></p>
            <input name="bntenviar" type="submit" value="Consultar" class="btn btn-outline-light">
            <input name="limpar" type="reset" value="Limpar" class="btn btn-outline-light">
            <button class="btn btn-outline-light"> <a href="menu.html" style="color: white; text-decoration: none;"> Voltar </a></button>
          </fieldset>
        </form>
      </div>
      <div class="col-lg-6">

</body>
</html>