<?php
include_once 'conectar.php';

class Autoria1
{
    private $Cod_autor;
    private $Cod_livro;
    private $DataLancamento;
    private $Editoria;
    private $conn;

    public function getCod_autor()
    {
        return $this->Cod_autor;
    }
    public function setCod_autor($codautor)
    {
        $this->Cod_autor = $codautor;
    }
    public function getCod_livro()
    {
        return $this->Cod_livro;
    }
    public function setCod_livro($codlivro)
    {
        $this->Cod_livro = $codlivro;
    }
    public function getDataLancamento()
    {
        return $this->DataLancamento;
    }
    public function setDataLancamento($Datalancamento)
    {
        $this->DataLancamento = $Datalancamento;
    }
    public function getEditoria()
    {
        return $this->Editoria;
    }
    public function setEditoria($editoria)
    {
        $this->Editoria = $editoria;
    }

  function salvar()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("INSERT INTO autoria1 VALUES (?, ?, ?, ?)");
            @$sql->bindParam(1, $this->getCod_autor(), PDO::PARAM_STR);
            @$sql->bindParam(2, $this->getCod_livro(), PDO::PARAM_STR);
            @$sql->bindParam(3, $this->getDataLancamento(), PDO::PARAM_STR);
            @$sql->bindParam(4, $this->getEditoria(), PDO::PARAM_STR);
            if ($sql->execute() == 1) {
                return "Registro salvo com sucesso!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao salvar o registro. " . $exc->getMessage();
        }
    }

    function alterar(){
        try {
           $this->conn = new Conectar();
           $sql = $this->conn->prepare("SELECT * FROM autoria1 WHERE Cod_autor = ?"); 
           @$sql-> bindParam(1, $this->getCod_autor(), PDO::PARAM_STR); 
           $sql->execute();
           return $sql->fetchAll();
           $this->conn = null;
}
      catch(PDOException $exc) {
      echo "Erro ao alterar. " . $exc->getMessage();

       }

   }

    function alterar2()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("UPDATE autoria1 SET Cod_livro = ?, DataLancamento = ?, Editoria = ?  WHERE Cod_autor = ?");
            @$sql->bindParam(1, $this->getCod_livro(), PDO::PARAM_STR);
            @$sql->bindParam(2, $this->getDataLancamento(), PDO::PARAM_STR);
            @$sql->bindParam(3, $this->getEditoria(), PDO::PARAM_STR);
            @$sql->bindParam(4, $this->getCod_autor(), PDO::PARAM_STR);
            if ($sql->execute() == 1) {
                return "Registro alterado com sucesso!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao salvar o registro. " . $exc->getMessage();
        }
    }
   function consultar()
   {
       try {
           $this->conn = new Conectar();
           $sql = $this->conn->prepare("SELECT * FROM autoria1 WHERE Editoria LIKE ?");
           @$sql->bindParam(1, $this->getEditoria(), PDO::PARAM_STR);
           $sql->execute();
           return $sql->fetchAll();
           $this->conn = null;
       } catch (PDOException $exc) {
           echo "Erro ao executar consulta. " . $exc->getMessage();
       }
   }
    function exclusao()
    {
        try {
            $this->conn = new Conectar();
            $cod_livro = $this->getCod_livro(); 
            $sql = $this->conn->prepare("DELETE FROM autoria1 WHERE Cod_livro = ?");
            $sql->bindParam(1, $cod_livro, PDO::PARAM_STR); 
            if ($sql->execute() == 1) {
                return "Excluído com sucesso!";
            } else {
                return "Erro na exclusão!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao excluir. " . $exc->getMessage();
        }
    }
    
    
    function listar()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("SELECT * FROM autoria1 ORDER BY Cod_autor");
            $sql->execute();
            return $sql->fetchAll();
            $this->conn = null;
        } catch (PDOException $e) {
            echo "Erro ao executar consulta. " . $e->getMessage();
        }
    }
}    
?>
