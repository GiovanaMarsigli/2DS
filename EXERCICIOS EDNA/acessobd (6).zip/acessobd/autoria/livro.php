<?php
include_once 'conectar.php';

class Livro
{
    private $Cod_livro;
    private $Titulo;
    private $Categoria;
    private $ISBN;
    private $Idioma;
    private $QtdePag;
    private $conn;

    public function getCod_livro()
    {
        return $this->Cod_livro;
    }
    public function setCod_livro($codlivro)
    {
        $this->Cod_livro = $codlivro;
    }
    public function getTitulo()
    {
        return $this->Titulo;
    }
    public function setTitulo($titulo)
    {
        $this->Titulo = $titulo;
    }
    public function getCategoria()
    {
        return $this->Categoria;
    }
    public function setCategoria($categoria)
    {
        $this->Categoria = $categoria;
    }
    public function getISBN()
    {
        return $this->ISBN;
    }
    public function setISBN($isbn)
    {
        $this->ISBN = $isbn;
    }
    public function getIdioma()
    {
        return $this->Idioma;
    }
    public function setIdioma($idioma)
    {
        $this->Idioma = $idioma;
    }

    public function getQtdePag()
    {
        return $this->QtdePag;
    }
    public function setQtdePag($qtdepag)
    {
        $this->QtdePag = $qtdepag;
    }



    function salvar()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("INSERT INTO livro VALUES (null, ?, ?, ?, ?, ?)");
            @$sql->bindParam(1, $this->getTitulo(), PDO::PARAM_STR);
            @$sql->bindParam(2, $this->getCategoria(), PDO::PARAM_STR);
            @$sql->bindParam(3, $this->getISBN(), PDO::PARAM_STR);
            @$sql->bindParam(4, $this->getIdioma(), PDO::PARAM_STR);
            @$sql->bindParam(5, $this->getQtdePag(), PDO::PARAM_STR);
            if ($sql->execute() == 1) {
                return "Registro salvo com sucesso!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao salvar o registro. " . $exc->getMessage();
        }
    }

    function alterar(){
         try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("SELECT * FROM livro WHERE Cod_livro = ?"); 
            @$sql-> bindParam(1, $this->getCod_livro(), PDO::PARAM_STR); 
            $sql->execute();
            return $sql->fetchAll();
             $this->conn = null;
 }
       catch(PDOException $exc) {
echo "Erro ao alterar. " . $exc->getMessage();

        }

    }

    function alterar2()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("UPDATE livro SET Titulo = ?, Categoria = ?, ISBN = ?, Idioma = ?, QtdePag = ? WHERE Cod_livro = ?");
            @$sql->bindParam(1, $this->getTitulo(), PDO::PARAM_STR);
            @$sql->bindParam(2, $this->getCategoria(), PDO::PARAM_STR);
            @$sql->bindParam(3, $this->getISBN(), PDO::PARAM_STR);
            @$sql->bindParam(4, $this->getIdioma(), PDO::PARAM_STR);
            @$sql->bindParam(5, $this->getQtdePag(), PDO::PARAM_STR);
            @$sql->bindParam(6, $this->getCod_livro(), PDO::PARAM_STR);

            if ($sql->execute() == 1) {
                return "Registro alterado com sucesso!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao salvar o registro. " . $exc->getMessage();
        }
    }

    function consultar()
    {
        try {
            $this->conn = new Conectar();
            $Titulo = $this->getTitulo(); 
            $sql = $this->conn->prepare("SELECT * FROM livro WHERE Titulo LIKE ?");
            $sql->bindParam(1, $Titulo, PDO::PARAM_STR); 
            $sql->execute();
            return $sql->fetchAll();
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao executar consulta. " . $exc->getMessage();
        }
    }
    
    function exclusao()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("DELETE FROM livro WHERE Cod_livro = ?");
            $codLivro = $this->getCod_livro(); 
            $sql->bindParam(1, $codLivro, PDO::PARAM_STR); 
            if ($sql->execute() == 1) {
                return "Excluído com sucesso!";
            } else {
                return "Erro na exclusão!";
            }
            $this->conn = null;
        } catch (PDOException $exc) {
            echo "Erro ao excluir. " . $exc->getMessage();
        }
    }
    
    
    function listar()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("SELECT * FROM livro ORDER BY Cod_livro");
            $sql->execute();
            return $sql->fetchAll();
            $this->conn = null;
        } catch (PDOException $e) {
            echo "Erro ao executar consulta. " . $e->getMessage();
        }
    }
}    
?>
