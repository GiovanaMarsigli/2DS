<?php
include_once 'conectar.php';

class Usuario
{
    private $usu;
    private $senha;
    private $conn;

    public function getUsu()
    {
        return $this->usu;
    }

    public function setUsu($usuario)
    {
        $this->usu = $usuario;
    }

    public function getSenha()
    {
        return $this->senha;
    }

    public function setSenha($senha)
    {
        $this->senha = $senha;
    }

    public function logar()
    {
        try {
            $this->conn = new Conectar();
            $sql = $this->conn->prepare("SELECT * FROM usuario WHERE login LIKE :login AND senha = :senha");

            // Store values in variables before binding
            $loginValue = $this->getUsu();
            $senhaValue = $this->getSenha();

            // Bind parameters using variables
            $sql->bindParam(':login', $loginValue, PDO::PARAM_STR);
            $sql->bindParam(':senha', $senhaValue, PDO::PARAM_STR);

            $sql->execute();
            return $sql->fetchAll();
        } catch (PDOException $exc) {
            echo "Erro ao executar consulta. " . $exc->getMessage();
        }
    }
}
?>
