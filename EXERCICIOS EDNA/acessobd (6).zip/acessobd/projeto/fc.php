<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giovana's Version - Fale Conosco</title>
    <link rel="icon" href="img/cobra.png" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="860x860" href="img/cobra.png">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <style>
        body {
            background-image: url('img/ts.jpg');
            background-size: cover;
            background-position: center; 
            background-repeat: no-repeat;
            color: #fff;
            font-family: 'Helvetica', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .login-container {
            background-color: #1a1a1a;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
            width: 300px;
            text-align: center;
        }
        
        h1 {
            color: #fff;
            font-size: 36px;
            margin-bottom: 30px;
            font-family: 'Noto Serif', sans-serif;
        }

        input[type="text"], input[type="password"], input[type="tel"] {
            border: none;
            border-bottom: 2px solid #fff;
            background: transparent;
            outline: none;
            color: #fff;
            margin-bottom: 20px;
            padding: 10px;
            width: 100%;
        }

        input[type="submit"] {
            background-color: #fff;
            color: #000;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #fff;
        }

        .login-link {
            color: #fff;
            text-decoration: none;
            margin-top: 10px;
            display: block;
        }

        .login-link:hover {
            text-decoration: underline;
        }  
    </style>


<script language="javascript">
            function Mascara() {
                var evento = window.event;
                var keypress = evento.keyCode;

                if (keypress >= 48 && keypress <= 57) {
                    var separado1 = '(';
                    var separado2 = ')';
                    var separado3 = '-';
                    var conjunto1 = 0;
                    var conjunto2 = 3;
                    var conjunto3 = 9;

                    if (document.cadastro.telefone.value.length == conjunto1) {
                        document.cadastro.telefone.value += separado1;
                    }
                    if (document.cadastro.telefone.value.length == conjunto2) {
                        document.cadastro.telefone.value += separado2;
                    }
                    if (document.cadastro.telefone.value.length == conjunto3) {
                        document.cadastro.telefone.value += separado3;
                    }
                    
                    return true;
                } else {
                    return false;
                }
            }
            
    function blokletras(event) {
      var key = event.key;
      if (!isNaN(key) || key === 'Backspace') {
        return true;
      } else {
        return false;
      }
    }

        </script>
    
</head>
<body>

<div class="login-container">
    <h1>Fale Conosco</h1>   
    <form method="post" name="cadastro">
                    <div class="input-box">
                        <input type="text" placeholder="Nome" name="nome" maxlength="15" required>
                    </div>
                    <div class="input-box">
                    <input type="text" placeholder="E-mail" name="email" id="email" required>
                    </div>
                    <div class="input-box">
                        <input type="text" placeholder="Telefone" name="telefone" maxlength="14"  required onkeypress="return Mascara()">
                    </div>
                    <button type="submit" name="btnconsultar" class="btn btn-primary">Enviar</button>
                </form>

    <a href="menu.html" class="login-link">Voltar para página inicial</a>
</div>

</body>
</html>
