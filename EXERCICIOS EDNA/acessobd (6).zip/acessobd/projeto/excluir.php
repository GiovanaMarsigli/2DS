<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Noto+Serif&display=swap" rel="stylesheet">

  <title>Giovana's Version</title>
  <link rel="icon" href="img/cobra.png" type="image/x-icon">
  <link rel="apple-touch-icon" sizes="860x860" href="img/cobra.png">
  <script>
    function blokletras(event) {
      var key = event.key;
      if (!isNaN(key) || key === 'Backspace') {
        return true;
      } else {
        return false;
      }
    }
  </script>
  <style>
    body {
      background-color: #727272;
      font-family: 'Noto Serif', sans-serif;
    }
    .navbar {
      font-size: 20px;
    }
    .navbar-nav .nav-link {
      font-size: 18px;
    }
    input[type="text"] {
      border-radius: 10px;
      padding: 10px;
      border: 1px solid #ccc;
    
    }
    .lovelace-legend {
      color: black;
      line-height: 50px;
      font-weight: 50;
      text-align: left;
      font-family: 'Noto Serif', Arial, sans-serif;
      font-size: 27px;
      margin-top:-150px;
    }
    .btn-container {
      text-align: left;
      margin-top: 20px;
    }
    .center-form {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
  </style>
</head>
<body class="px-0 px-5 m-0 border-0 bd-example">
  <nav class="navbar navbar-expand-lg bg-custom-color">
    <div class="container">
      <a class="navbar-brand" href="menu.html">
        <img src="img/REPUTATIONLOGO.png" alt="LOGO" width="155" height="100">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item">
            <a class="nav-link" href="cadastrar.php">Cadastrar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="excluir.php">Excluir</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="pesquisar.php">Pesquisar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="listar.php">Listar</a>
          </li>
          <li class="nav-item">
          <a class="nav-link" href="consultar_alt.php">Alterar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="fc.php">Fale conosco</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="sobre.html">Sobre</a>
          </li>
        </ul>
      </div>
    </div>
    </nav>
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <img class="srounded img-fluid rounded d-none d-lg-block" src="img/excluirtaylor.png" alt="Imagem de exemplo" style="width: 100%;">
      </div>
      <div class="col-md-6 center-form">
        <p class="lovelace-legend">Informe o ID do produto desejado:</p>
        <form name="cliente" method="POST" action="" class="form-container">
          <fieldset id="a">
            <p><input name="getId" type="text" size="60" maxlength="40" placeholder="Insira o ID do livro" onkeypress="return blokletras(event)"></p>
          </fieldset>
          <fieldset id="b">
            <button class="btn btn-outline-light" type="submit" name="btnenviar">Excluir</button>
            <button class="btn btn-outline-light" type="reset" name="limpar">Limpar</button>
            <a class="btn btn-outline-light" href="menu.html">Voltar</a>
          </fieldset>
        </form>
      </div>
    </div>
  </div>
  <fieldset id="c">
    <?php
      extract($_POST, EXTR_OVERWRITE);
      if (isset($btnenviar))
      {
        include_once 'Produto.php';
        $pro=new Produto();
        $pro->setId($getId);
    echo"<h3>".$pro->exclusao(). "</h3>";
 }
 ?>
</body>
</html>




