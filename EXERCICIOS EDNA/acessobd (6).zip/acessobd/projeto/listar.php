<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Noto+Serif&display=swap" rel="stylesheet">

  <title>Giovana's Version</title>
  <link rel="icon" href="img/cobra.png" type="image/x-icon">
  <link rel="apple-touch-icon" sizes="860x860" href="img/cobra.png">
  
  <style>
    body {
      background-color: #727272;
    }
    .navbar {
      font-family: 'Noto Serif', sans-serif;
      font-size: 20px;
    }
    .float-end {
      display: block;
      margin-left: auto;
      margin-right: 150px;
      max-width: 600px;
      margin-top: 10px;
    }
    .lovelace-legend {
      color: black;
      line-height: 50px;
      font-weight: 500;
      text-align: CENTER;
      margin-left: auto;
      margin-right: auto;
      max-width: 450px;
      font-family: 'Noto Serif', Arial, sans-serif;
      font-size: 27px;
    }
    .produto-info {
      color: black;
      line-height: 50px;
      font-weight: 50;
      text-align: LEFT;
      margin-left: 55px;
      margin-right: auto;
      max-width: 450px;
      font-family: 'Noto Serif', Arial, sans-serif;
      font-size: 18px;
    }
  </style>
</head>
<body class="px-0 px-5 m-0 border-0 bd-example">
  <nav class="navbar navbar-expand-lg bg-custom-color">
    <div class="container">
      <a class="navbar-brand" href="menu.html">
        <img src="img/REPUTATIONLOGO.png" alt="LOGO" width="155" height="100">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
        <li class="nav-item">
            <a class="nav-link" href="cadastrar.php">Cadastrar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="excluir.php">Excluir</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="pesquisar.php">Pesquisar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="listar.php">Listar</a>
          </li>
          <li class="nav-item">
          <a class="nav-link" href="consultar_alt.php">Alterar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="fc.php">Fale conosco</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="sobre.html">Sobre</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <img class="srounded float-end  d-none d-lg-block" src="img/listartaylor.png" alt="Imagem de exemplo" style="width: 700px;"> 
<BR>
<legend class="lovelace-legend"><b>PRODUTOS CADASTRADOS</b></legend><BR>
<div class="produto-info">
<?php
include_once 'produto.php';
$p = new Produto();
$pro_bd = $p->listar();
?>
<b> Id &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nome &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Estoque</b>
<?php

  foreach ($pro_bd as $pro_mostrar){ ?>
  <br><br>
  <b> <?php echo $pro_mostrar[0]; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <b> <?php echo $pro_mostrar[1]; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <b> <?php echo $pro_mostrar[2]; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<?php
  }
echo "<br><br><button onclick=\"window.location.href='menu.html'\" class='btn btn-outline-light'>Voltar</button>";
?>
</DIV>
</body>
</html>
